import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../core/config/app_config.dart';
import '../models/campaign.dart';
import '../models/coupon.dart';
import '../models/promotion.dart';
import '../models/store.dart';

class AuthResult {
  const AuthResult({
    required this.token,
    required this.userId,
    required this.name,
    required this.email,
    required this.phone,
    required this.cpf,
    required this.sexo,
    required this.dataNascimento,
  });
  final String token;
  final int userId;
  final String name;
  final String email;
  final String phone;
  final String cpf;
  final String sexo;
  final DateTime dataNascimento;
}

/// Uma linha do extrato — pode ser uma compra (nota fiscal aprovada) ou um
/// ajuste manual de pontos feito por um admin pelo painel (bônus, correção
/// etc.). [type] diferencia os dois ("Compra" ou "Ajuste"); os campos que só
/// fazem sentido pra compra (loja, valor) ficam nulos num ajuste, e vice-versa
/// ([reason] só existe em ajustes). Ver GSDIShoppingApi/Dtos/Wallet/WalletDtos.cs.
class WalletEntry {
  const WalletEntry({
    required this.id,
    required this.type,
    this.storeId,
    this.storeName,
    this.totalValue,
    required this.pointsDelta,
    required this.status,
    this.reason,
    required this.createdAt,
  });
  final int id;
  final String type;
  final int? storeId;
  final String? storeName;
  final double? totalValue;
  final int pointsDelta;
  final String status;
  final String? reason;
  final DateTime createdAt;

  bool get isCompra => type == 'Compra';

  factory WalletEntry.fromJson(Map<String, dynamic> json) => WalletEntry(
        id: json['id'] as int,
        type: json['type'] as String,
        storeId: json['storeId'] as int?,
        storeName: json['storeName'] as String?,
        totalValue: (json['totalValue'] as num?)?.toDouble(),
        pointsDelta: json['pointsDelta'] as int,
        status: json['status'] as String,
        reason: json['reason'] as String?,
        createdAt: DateTime.parse(json['createdAt'] as String),
      );
}

class ReceiptValidationResult {
  const ReceiptValidationResult({
    required this.approved,
    this.rejectionReason,
    required this.pointsEarned,
    required this.newPointsBalance,
  });
  final bool approved;
  final String? rejectionReason;
  final int pointsEarned;
  final int newPointsBalance;

  factory ReceiptValidationResult.fromJson(Map<String, dynamic> json) => ReceiptValidationResult(
        approved: json['approved'] as bool,
        rejectionReason: json['rejectionReason'] as String?,
        pointsEarned: json['pointsEarned'] as int,
        newPointsBalance: json['newPointsBalance'] as int,
      );
}

/// Cliente do backend próprio (GSDIShoppingApi — ASP.NET Core + MySQL).
/// Cuida de autenticação do cliente final, saldo/extrato de pontos,
/// validação de nota fiscal e (via painel de administração) o cadastro
/// de lojas/campanhas/cupons — tudo no mesmo backend e banco.
class GSDIShoppingApiService {
  GSDIShoppingApiService({Dio? dio})
      : _dio = dio ?? Dio(BaseOptions(baseUrl: AppConfig.gsdiShoppingApiBaseUrl)) {
    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        final token = await _storage.read(key: _tokenKey);
        if (token != null) {
          options.headers['Authorization'] = 'Bearer $token';
        }
        handler.next(options);
      },
    ));
  }

  final Dio _dio;
  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  static const _tokenKey = 'gsdishopping_api_token';

  Future<AuthResult> register({
    required String name,
    required String email,
    required String password,
    required String phone,
    required String cpf,
    required String sexo,
    required DateTime dataNascimento,
  }) async {
    final response = await _dio.post<Map<String, dynamic>>('/auth/register', data: {
      'name': name,
      'email': email,
      'password': password,
      'phone': phone,
      'cpf': cpf,
      'sexo': sexo,
      // yyyy-MM-dd — o backend espera um DateOnly.
      'dataNascimento':
          '${dataNascimento.year.toString().padLeft(4, '0')}-'
          '${dataNascimento.month.toString().padLeft(2, '0')}-'
          '${dataNascimento.day.toString().padLeft(2, '0')}',
    });
    return _saveAuthResponse(response.data!);
  }

  Future<AuthResult> login({required String email, required String password}) async {
    final response = await _dio.post<Map<String, dynamic>>('/auth/login', data: {
      'email': email,
      'password': password,
    });
    return _saveAuthResponse(response.data!);
  }

  Future<AuthResult> _saveAuthResponse(Map<String, dynamic> data) async {
    final token = data['token'] as String;
    await _storage.write(key: _tokenKey, value: token);
    return AuthResult(
      token: token,
      userId: data['userId'] as int,
      name: data['name'] as String,
      email: data['email'] as String,
      phone: data['phone'] as String,
      cpf: data['cpf'] as String,
      sexo: data['sexo'] as String,
      dataNascimento: DateTime.parse(data['dataNascimento'] as String),
    );
  }

  Future<void> signOut() => _storage.delete(key: _tokenKey);

  Future<bool> get isLoggedIn async => (await _storage.read(key: _tokenKey)) != null;

  Future<int> getBalance() async {
    final response = await _dio.get<Map<String, dynamic>>('/wallet/balance');
    return response.data!['pointsBalance'] as int;
  }

  Future<List<WalletEntry>> getTransactions() async {
    final response = await _dio.get<List<dynamic>>('/wallet/transactions');
    return response.data!
        .cast<Map<String, dynamic>>()
        .map(WalletEntry.fromJson)
        .toList();
  }

  /// Busca lojas cadastradas, opcionalmente filtrando por CNPJ. Usado na
  /// tela de scanner para descobrir, a partir do CNPJ lido no QR code, se
  /// a nota é de uma loja do shopping — e para mostrar o nome da loja ao
  /// usuário antes de enviar para validação. Devolve null se nenhuma loja
  /// tiver esse CNPJ (a checagem que vale de verdade é sempre refeita no
  /// backend, isso aqui é só feedback antecipado).
  Future<Store?> findStoreByCnpj(String cnpj) async {
    final response = await _dio.get<List<dynamic>>(
      '/catalog/stores',
      queryParameters: {'cnpj': cnpj},
    );
    final items = response.data ?? const [];
    if (items.isEmpty) return null;
    return Store.fromJson(items.first as Map<String, dynamic>);
  }

  /// Lista todas as lojas do shopping — usado na tela "Lojas" (Fase 2),
  /// diferente de [findStoreByCnpj] (que filtra uma só, para o scanner).
  Future<List<Store>> listStores() async {
    final response = await _dio.get<List<dynamic>>('/catalog/stores');
    return (response.data ?? const [])
        .cast<Map<String, dynamic>>()
        .map(Store.fromJson)
        .toList();
  }

  Future<List<Campaign>> listCampaigns() async {
    final response = await _dio.get<List<dynamic>>('/catalog/campaigns');
    return (response.data ?? const [])
        .cast<Map<String, dynamic>>()
        .map(Campaign.fromJson)
        .toList();
  }

  /// Cupons de uma campanha (é assim que a tela de campanha busca os dela)
  /// ou, sem [campaignId], todos os cupons do catálogo.
  Future<List<Coupon>> listCoupons({int? campaignId}) async {
    final response = await _dio.get<List<dynamic>>(
      '/catalog/coupons',
      queryParameters: {if (campaignId != null) 'campaignId': campaignId},
    );
    return (response.data ?? const [])
        .cast<Map<String, dynamic>>()
        .map(Coupon.fromJson)
        .toList();
  }

  /// Promoções de uma loja (tela de detalhe da loja) ou, sem [storeId],
  /// todas — inclui tanto promoções de loja quanto promoções gerais do
  /// shopping (ver [Promotion.isMallWide]).
  Future<List<Promotion>> listPromotions({int? storeId}) async {
    final response = await _dio.get<List<dynamic>>(
      '/catalog/promotions',
      queryParameters: {if (storeId != null) 'storeId': storeId},
    );
    return (response.data ?? const [])
        .cast<Map<String, dynamic>>()
        .map(Promotion.fromJson)
        .toList();
  }

  /// Envia a chave de acesso lida do QR code (+ CNPJ extraído dela) para o
  /// backend validar. Não envia storeId: o próprio backend resolve a loja
  /// a partir do storeCnpj e aplica a checagem de elegibilidade lá.
  Future<ReceiptValidationResult> validateReceipt({
    required String accessKey,
    required String storeCnpj,
    required double totalValue,
  }) async {
    final response = await _dio.post<Map<String, dynamic>>('/receipts/validate', data: {
      'accessKey': accessKey,
      'storeCnpj': storeCnpj,
      'totalValue': totalValue,
    });
    return ReceiptValidationResult.fromJson(response.data!);
  }
}
