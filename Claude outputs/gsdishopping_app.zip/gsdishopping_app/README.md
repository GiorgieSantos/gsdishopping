# gsdishopping_app

Scaffold inicial do app de fidelidade do shopping. Este pacote traz a
estrutura de código Dart/Flutter (models, services, telas); os projetos
nativos `ios/` e `android/` **precisam ser gerados na sua máquina** com o
Flutter SDK instalado — eles dependem da sua versão do Flutter/Xcode e não
fazem sentido gerar fora do seu Mac.

## 1. Pré-requisitos no Mac

- Xcode (App Store) + Command Line Tools (`xcode-select --install`)
- Flutter SDK: `brew install --cask flutter` ou seguindo
  https://docs.flutter.dev/get-started/install/macos
- Uma conta de desenvolvedor Apple (gratuita serve para rodar no simulador
  e no seu próprio iPhone; a conta paga — US$ 99/ano — só é necessária
  para publicar na App Store)
- CocoaPods: `sudo gem install cocoapods`

Rode `flutter doctor` e resolva qualquer item marcado com "✗" antes de
prosseguir.

## 2. Gerar os projetos nativos

Dentro desta pasta:

```bash
flutter create . --project-name gsdishopping_app --org br.com.seudominio
flutter pub get
```

Isso cria `ios/` e `android/` a partir dos templates oficiais do Flutter,
mantendo o `lib/` que já está pronto aqui.

## 2.5. Permissões de câmera (obrigatório para o scanner funcionar)

Os pacotes `camera` (foto do corpo da nota) e `mobile_scanner` (leitura do
QR code) só funcionam com essas permissões declaradas. Sem isso o app
trava ou nega o acesso à câmera silenciosamente.

**iOS** — em `ios/Runner/Info.plist`, adicione (como irmã das outras
chaves, dentro do `<dict>` principal):

```xml
<key>NSCameraUsageDescription</key>
<string>Usamos a câmera para ler o QR code e fotografar o cupom fiscal.</string>
```

**Android** — em `android/app/src/main/AndroidManifest.xml`, adicione
dentro da tag `<manifest>` (fora da `<application>`):

```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-feature android:name="android.hardware.camera" android:required="false" />
<uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />
```

## 3. Abrir no Xcode (para assinatura e build de iOS)

```bash
open ios/Runner.xcworkspace
```

No Xcode: selecione o target **Runner** → aba **Signing & Capabilities** →
escolha seu Team (conta Apple) → ajuste o Bundle Identifier (ex.:
`br.com.seudominio.gsdishoppingapp`). Isso é tudo que o Xcode faz aqui — o
desenvolvimento das telas continua em `lib/`, editado no VS Code/Android
Studio; o Xcode entra só nesta etapa de assinatura/build e para rodar no
simulador iOS.

## 4. Configurar a URL do backend

O app fala com um único backend (ver `ARQUITETURA_TECNICA.md`, seção 8 —
o Squidex foi descontinuado, tudo mora no GSDIShoppingApi): login,
carteira de pontos, validação de nota fiscal e catálogo (lojas, campanhas,
cupons, promoções). Ao rodar/buildar, passe a URL via `--dart-define`:

```bash
flutter run \
  --dart-define=GSDISHOPPING_API_BASE_URL=https://localhost:7100/api
```

(ver `lib/core/config/app_config.dart`; a porta do GSDIShoppingApi aparece no
console quando você roda `dotnet run` nele — ver o README daquele projeto)

## 5. Rodar

```bash
flutter run
```

Escolha o simulador iOS ou um dispositivo físico quando solicitado.

## O que ainda falta implementar

- Subir o backend GSDIShoppingApi (projeto ASP.NET Core entregue junto) e
  cadastrar pelo menos uma loja, uma campanha, um cupom e uma promoção de
  teste nele (ver o README daquele projeto, seções "Cadastrar lojas de
  teste" e "Cadastrar campanhas, cupons e promoções de teste") — sem loja
  cadastrada, login/carteira funcionam mas o scan de nota sempre rejeita
  por "loja fora do shopping"; sem campanha/cupom/promoção, as telas de
  Lojas/Campanhas ficam vazias
- Testar o fluxo de scanner num dispositivo/emulador de verdade (câmera
  real) — feito e revisado neste ambiente, mas nunca rodado numa câmera
  física; o comportamento em emuladores sem câmera é degradar de forma
  graciosa (deixa enviar sem preview de foto), vale confirmar que isso
  também é o desejado
- Aplicar o layout do mockup de identidade visual ("Vitrine GSDIShopping")
  às telas de verdade — hoje elas já herdam a paleta/tipografia definidas
  (`lib/core/theme/app_theme.dart`), mas usam a estrutura padrão do
  Material (listas simples), não o layout específico desenhado no mockup
  (cartão de pontos, carrossel de banner, grade de lojas em destaque etc.)
- Fluxo de resgate de cupom (gastar pontos por um cupom) — a Fase 2
  entregou só a leitura do catálogo; o cliente ainda não consegue de fato
  resgatar um cupom pelo app
