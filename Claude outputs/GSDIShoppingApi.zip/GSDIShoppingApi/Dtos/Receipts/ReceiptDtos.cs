namespace GSDIShoppingApi.Dtos.Receipts;

/// <summary>
/// Enviado pelo app depois que o cliente lê o QR code da nota (e,
/// opcionalmente, confirma o valor via OCR local). Não inclui StoreId de
/// propósito — o backend resolve a loja sozinho a partir do StoreCnpj
/// (ver PointsService), para que a checagem de elegibilidade não dependa
/// de nada que o cliente afirme.
/// </summary>
public record ValidateReceiptRequest(
    string AccessKey,
    string StoreCnpj,
    decimal TotalValue
);

public record ValidateReceiptResponse(
    bool Approved,
    string? RejectionReason,
    int PointsEarned,
    int NewPointsBalance
);
