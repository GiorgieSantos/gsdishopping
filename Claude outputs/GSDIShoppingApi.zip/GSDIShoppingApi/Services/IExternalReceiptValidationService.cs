namespace GSDIShoppingApi.Services;

public record ExternalValidationResult(bool Approved, string? Reason);

/// <summary>
/// Contrato entre esta API e o seu serviço externo de validação de nota
/// fiscal. A implementação real (<see cref="ExternalReceiptValidationService"/>)
/// só faz um POST HTTP — toda a lógica de checar a nota na SEFAZ do
/// estado, etc. vive no seu serviço, não aqui.
/// </summary>
public interface IExternalReceiptValidationService
{
    Task<ExternalValidationResult> ValidateAsync(
        string accessKey,
        string storeCnpj,
        decimal totalValue,
        CancellationToken cancellationToken);
}
