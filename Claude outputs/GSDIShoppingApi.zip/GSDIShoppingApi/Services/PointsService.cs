using GSDIShoppingApi.Data;
using GSDIShoppingApi.Dtos.Receipts;
using GSDIShoppingApi.Models;
using Microsoft.EntityFrameworkCore;
using MySqlConnector;

namespace GSDIShoppingApi.Services;

/// <summary>
/// Orquestra a regra "validar se os pontos das notas são reais": confere
/// duplicidade localmente, delega a validação de autenticidade ao seu
/// serviço externo, calcula os pontos e grava tudo de forma auditável.
/// </summary>
public class PointsService(
    GSDIShoppingDbContext db,
    IExternalReceiptValidationService externalValidation,
    IConfiguration config) : IPointsService
{
    public async Task<ValidateReceiptResponse> ProcessReceiptAsync(
        int userId,
        ValidateReceiptRequest request,
        CancellationToken cancellationToken)
    {
        // 1) Barreira rápida e barata: já existe uma nota com esta chave?
        //    Evita gastar uma chamada ao serviço externo à toa.
        var alreadyExists = await db.PointTransactions
            .AnyAsync(t => t.AccessKey == request.AccessKey, cancellationToken);

        if (alreadyExists)
        {
            var currentBalance = await GetBalanceAsync(userId, cancellationToken);
            return new ValidateReceiptResponse(
                Approved: false,
                RejectionReason: "Esta nota fiscal já foi utilizada.",
                PointsEarned: 0,
                NewPointsBalance: currentBalance);
        }

        // 2) Checagem de elegibilidade: o CNPJ da nota precisa ser de uma
        //    loja cadastrada no shopping. Resolvemos a loja aqui, no
        //    servidor, a partir do CNPJ — nunca confiamos num StoreId que
        //    viesse do app, porque isso seria fácil de forjar. Sem essa
        //    checagem, qualquer nota com QR code bem formatado pontuaria,
        //    mesmo de um estabelecimento fora do shopping.
        var cnpjDigits = DocumentValidators.OnlyDigits(request.StoreCnpj);
        var store = await db.Stores.SingleOrDefaultAsync(s => s.Cnpj == cnpjDigits, cancellationToken);
        if (store is null)
        {
            var currentBalance = await GetBalanceAsync(userId, cancellationToken);
            return new ValidateReceiptResponse(
                Approved: false,
                RejectionReason: "Esta nota é de uma loja que não faz parte do shopping.",
                PointsEarned: 0,
                NewPointsBalance: currentBalance);
        }

        // 3) Validação de autenticidade no seu serviço externo.
        var result = await externalValidation.ValidateAsync(
            request.AccessKey, request.StoreCnpj, request.TotalValue, cancellationToken);

        var reaisPerPoint = config.GetValue("Points:ReaisPerPoint", 1.0m);
        var pointsEarned = result.Approved
            ? (int)Math.Floor(request.TotalValue / reaisPerPoint)
            : 0;

        var transaction = new PointTransaction
        {
            UserId = userId,
            StoreId = store.Id,
            AccessKey = request.AccessKey,
            TotalValue = request.TotalValue,
            PointsEarned = pointsEarned,
            Status = result.Approved ? ReceiptStatus.Approved : ReceiptStatus.RejectedInvalid,
            RejectionReason = result.Reason,
            ValidatedAt = DateTime.UtcNow,
        };

        db.PointTransactions.Add(transaction);

        try
        {
            await db.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateException ex) when (IsDuplicateKeyViolation(ex))
        {
            // Corrida rara: duas requisições com a mesma chave passaram
            // pela checagem acima ao mesmo tempo. O índice único do banco
            // (ver GSDIShoppingDbContext) é a garantia final — aqui só traduzimos
            // o erro numa resposta amigável em vez de deixar a exceção estourar.
            var currentBalance = await GetBalanceAsync(userId, cancellationToken);
            return new ValidateReceiptResponse(
                Approved: false,
                RejectionReason: "Esta nota fiscal já foi utilizada.",
                PointsEarned: 0,
                NewPointsBalance: currentBalance);
        }

        var newBalance = await GetBalanceAsync(userId, cancellationToken);

        return new ValidateReceiptResponse(
            result.Approved,
            result.Reason,
            pointsEarned,
            newBalance);
    }

    /// <summary>MySQL error 1062 = "Duplicate entry" (violação de índice único).</summary>
    private static bool IsDuplicateKeyViolation(DbUpdateException ex) =>
        ex.InnerException is MySqlException { Number: 1062 };

    public async Task<int> GetBalanceAsync(int userId, CancellationToken cancellationToken)
    {
        var fromTransactions = await db.PointTransactions
            .Where(t => t.UserId == userId && t.Status == ReceiptStatus.Approved)
            .SumAsync(t => (int?)t.PointsEarned, cancellationToken) ?? 0;

        // Ajustes manuais de admin (bônus/correção/estorno) entram no
        // mesmo somatório — ver Models/PointsAdjustment.cs.
        var fromAdjustments = await db.PointsAdjustments
            .Where(a => a.UserId == userId)
            .SumAsync(a => (int?)a.PointsDelta, cancellationToken) ?? 0;

        return fromTransactions + fromAdjustments;
    }
}
