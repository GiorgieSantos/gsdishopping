using System.Net.Http.Json;

namespace GSDIShoppingApi.Services;

/// <summary>
/// Chama o seu serviço externo de validação de nota fiscal.
///
/// Contrato esperado (ajuste a rota/payload conforme o serviço que você
/// construir — este é só o formato que esta API já envia por padrão):
///
///   POST {ExternalValidation:BaseUrl}/validate
///   Headers: X-Api-Key: {ExternalValidation:ApiKey}   (se configurado)
///   Body:    { "accessKey": "...", "storeCnpj": "...", "totalValue": 123.45 }
///
///   Resposta esperada (200 OK):
///   { "approved": true, "reason": null }
///   { "approved": false, "reason": "nota não encontrada na SEFAZ" }
///
/// Se o seu serviço externo usar outro formato, o único lugar que precisa
/// mudar é este arquivo — o resto da API (PointsService, controllers)
/// depende só da interface IExternalReceiptValidationService.
/// </summary>
public class ExternalReceiptValidationService(HttpClient httpClient, IConfiguration config)
    : IExternalReceiptValidationService
{
    public async Task<ExternalValidationResult> ValidateAsync(
        string accessKey,
        string storeCnpj,
        decimal totalValue,
        CancellationToken cancellationToken)
    {
        var apiKey = config["ExternalValidation:ApiKey"];
        using var request = new HttpRequestMessage(HttpMethod.Post, "validate")
        {
            Content = JsonContent.Create(new
            {
                accessKey,
                storeCnpj,
                totalValue,
            }),
        };
        if (!string.IsNullOrWhiteSpace(apiKey))
        {
            request.Headers.Add("X-Api-Key", apiKey);
        }

        using var response = await httpClient.SendAsync(request, cancellationToken);

        if (!response.IsSuccessStatusCode)
        {
            // Serviço externo fora do ar ou erro inesperado: rejeita por
            // segurança em vez de creditar pontos sem confirmação.
            return new ExternalValidationResult(
                Approved: false,
                Reason: $"Serviço de validação retornou {(int)response.StatusCode}.");
        }

        var payload = await response.Content.ReadFromJsonAsync<ExternalValidationPayload>(
            cancellationToken: cancellationToken);

        return new ExternalValidationResult(
            payload?.Approved ?? false,
            payload?.Reason);
    }

    private sealed record ExternalValidationPayload(bool Approved, string? Reason);
}
