using GSDIShoppingApi.Dtos.Receipts;

namespace GSDIShoppingApi.Services;

public interface IPointsService
{
    Task<ValidateReceiptResponse> ProcessReceiptAsync(
        int userId,
        ValidateReceiptRequest request,
        CancellationToken cancellationToken);

    /// <summary>Saldo atual: soma de PointsEarned aprovados em PointTransactions MAIS soma de PointsDelta em PointsAdjustments. Nunca um contador.</summary>
    Task<int> GetBalanceAsync(int userId, CancellationToken cancellationToken);
}
