# GSDIShoppingApi

Backend próprio (ASP.NET Core 8 + MySQL) responsável por: autenticação do
cliente final, saldo/extrato de pontos, a orquestração da validação de
nota fiscal com o seu serviço externo, e o cadastro de lojas, campanhas
e cupons (via painel de administração). Não há mais dependência do
Squidex — tudo vive neste backend e no nosso MySQL.

## Aviso importante sobre este ambiente

Este código foi escrito e revisado nesta sessão, com .NET 8 SDK e MySQL
instalados e funcionando aqui. Mas **não consegui rodar `dotnet restore`
neste sandbox**: a política de rede desta sessão bloqueia o acesso a
`api.nuget.org` (onde ficam os pacotes Pomelo.EntityFrameworkCore.MySql,
JWT Bearer e BCrypt.Net-Next que o projeto usa) — é um bloqueio de
política, não algo que dá para contornar por aqui. Ou seja: não consegui
compilar nem testar de ponta a ponta neste ambiente. No seu Mac isso não
deve ser um problema (acesso normal à internet), mas rode os passos abaixo
com atenção e me avise se aparecer algum erro de compilação — reviso e
corrijo.

## 1. Pré-requisitos no Mac

- .NET 8 SDK: `brew install --cask dotnet-sdk` ou https://dotnet.microsoft.com/download/dotnet/8.0
- MySQL local (`brew install mysql && brew services start mysql`) ou um
  container Docker (`docker run -d -p 3306:3306 -e MYSQL_ROOT_PASSWORD=root mysql:8`)

## 2. Criar o banco

```bash
mysql -u root -p -e "CREATE DATABASE gsdishopping_app CHARACTER SET utf8mb4;"
mysql -u root -p gsdishopping_app < schema.sql
```

> **Se você já tinha criado este banco antes** (na Fase 0, ex.: pra testar
> login): não precisa apagar o banco todo. O `schema.sql` mudou só em duas
> coisas — a tabela `Stores` (nova) e `PointTransactions.StoreId`, que
> deixou de ser texto livre e virou chave estrangeira para `Stores`. A
> tabela `Users` (login/cadastro) não muda em nada, seus usuários de teste
> continuam valendo. Rode a migração incremental que cuida só dessas duas
> tabelas:
> `mysql -u root -p gsdishopping_app < migration_fase1.sql`
> (ela recria `PointTransactions` do zero — normal, essa tabela não tinha
> uso real na Fase 0 porque a checagem de elegibilidade não existia ainda;
> se você tiver transações de teste ali que queira preservar de verdade, me
> avise antes de rodar). Só apague o banco inteiro se preferir recomeçar do
> zero por algum outro motivo.

> **Se você já rodou a Fase 1** e só precisa das tabelas novas da Fase 2
> (`Campaigns`, `Coupons`, `Promotions` — catálogo de campanhas/cupons/
> promoções): é só isso, aditivo, nada existente muda.
> `mysql -u root -p gsdishopping_app < migration_fase2.sql`

> **Se você já rodou a Fase 2** e só precisa das tabelas novas da Fase 3
> (`AdminUsers`, `PointsAdjustments` — login do painel e ajustes manuais
> de pontos): também é só isso, aditivo.
> `mysql -u root -p gsdishopping_app < migration_fase3.sql`

## 2.5. Sem o seu serviço de validação pronto ainda?

Use o `ValidationMock` (entregue junto, na pasta ao lado desta) — é um
"dublê" que aprova qualquer nota com chave de acesso no formato certo, só
para você testar o fluxo completo (app → GSDIShoppingApi → validação → pontos)
antes de implementar a integração real com a SEFAZ. Ver o `README.md`
dele.

## 3. Configurar segredos (não deixe hardcoded em produção)

Edite `appsettings.Development.json` (ou use `dotnet user-secrets`) com:

- `ConnectionStrings:Default` — usuário/senha do seu MySQL local
- `Jwt:Key` — uma string aleatória de pelo menos 32 caracteres
- `ExternalValidation:BaseUrl` — a URL do seu serviço de validação de nota
  fiscal (ver contrato esperado em `Services/ExternalReceiptValidationService.cs`)

## 4. Restaurar, compilar e rodar

```bash
dotnet restore
dotnet build
dotnet run
```

A API sobe por padrão em `https://localhost:7xxx` (a porta exata aparece
no console — também está em `Properties/launchSettings.json`). Com
`ASPNETCORE_ENVIRONMENT=Development`, o Swagger fica disponível em
`/swagger` para testar os endpoints pelo navegador.

Se preferir gerar as migrations do EF Core em vez de usar `schema.sql`:

```bash
dotnet tool install --global dotnet-ef
dotnet ef migrations add InitialCreate
dotnet ef database update
```

## 5. Testar com curl

```bash
# Cadastro
curl -k -X POST https://localhost:7xxx/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Maria","email":"maria@exemplo.com","password":"senha123","phone":"11987654321","cpf":"52998224725","sexo":"Outro","dataNascimento":"1990-01-01"}'

# Login (copie o "token" da resposta)
curl -k -X POST https://localhost:7xxx/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"maria@exemplo.com","password":"senha123"}'

# Saldo (endpoint autenticado)
curl -k https://localhost:7xxx/api/wallet/balance \
  -H "Authorization: Bearer SEU_TOKEN_AQUI"
```

## 5.5. Cadastrar lojas de teste (catálogo)

Antes de testar o scan de nota, cadastre pelo menos uma loja — sem isso,
`POST /api/receipts/validate` sempre rejeita por "loja fora do shopping"
(essa é a regra de elegibilidade da Fase 1). Pode ser pelo Swagger
(`/swagger`, endpoint `POST /api/catalog/stores`) ou por curl:

```bash
curl -k -X POST https://localhost:7xxx/api/catalog/stores \
  -H "Content-Type: application/json" \
  -d '{"name":"Loja Teste","cnpj":"11222333000181","floor":"L1"}'

# Conferir que ficou salva (e testar o filtro por CNPJ, que é o que o app usa):
curl -k "https://localhost:7xxx/api/catalog/stores?cnpj=11222333000181"
```

Esse endpoint de cadastro está **sem autenticação de propósito**, só para
você conseguir dar carga de teste antes do painel de administração
(Fase 3) existir. Quando o painel chegar, ele passa a exigir login de
admin.

## 5.6. Cadastrar campanhas, cupons e promoções de teste (Fase 2)

Mesma ideia da seção anterior — sem isso, as telas novas do app (Lojas,
Campanhas, Promoções) carregam vazias. Lembrando a diferença entre os
dois conceitos: **cupom** é algo que o cliente resgata gastando pontos, e
sempre pertence a uma campanha; **promoção** é só um anúncio de desconto
de uma loja (ou do shopping, se `storeId` for nulo), sem custo em pontos.

```bash
# 1) Campanha — anote o "id" da resposta, é o campaignId do cupom abaixo
curl -k -X POST https://localhost:7xxx/api/catalog/campaigns \
  -H "Content-Type: application/json" \
  -d '{"title":"Semana da Moda","description":"Até 20% em lojas selecionadas","startsAt":"2026-09-10T00:00:00Z","endsAt":"2026-09-20T00:00:00Z"}'

# 2) Cupom dentro dessa campanha (troque campaignId pelo id retornado acima)
curl -k -X POST https://localhost:7xxx/api/catalog/coupons \
  -H "Content-Type: application/json" \
  -d '{"title":"10% OFF na Bella Moda","description":"Válido na loja física","pointsCost":150,"campaignId":1}'

# 3) Promoção de uma loja específica (troque storeId por um id de loja já cadastrada — ver seção 5.5)
curl -k -X POST https://localhost:7xxx/api/catalog/promotions \
  -H "Content-Type: application/json" \
  -d '{"title":"Segunda em dobro","description":"Compre 1 leve 2 em toda a loja","discountLabel":"Leve 2 pague 1","storeId":1}'

# 4) Promoção geral do shopping (storeId nulo)
curl -k -X POST https://localhost:7xxx/api/catalog/promotions \
  -H "Content-Type: application/json" \
  -d '{"title":"Estacionamento grátis","description":"Toda quinta-feira, após as 18h","discountLabel":"Grátis"}'

# Conferir:
curl -k https://localhost:7xxx/api/catalog/campaigns
curl -k "https://localhost:7xxx/api/catalog/coupons?campaignId=1"
curl -k https://localhost:7xxx/api/catalog/promotions
```

A partir da Fase 3, estes quatro endpoints de cadastro (lojas, campanhas,
cupons, promoções) passaram a exigir login de admin — ver seção 5.7.

## 5.7. Painel de administração (Fase 3)

O painel roda dentro deste mesmo backend (Blazor Server), em
`https://localhost:7xxx/admin`. É lá que você cadastra lojas, campanhas,
cupons e promoções pela interface (em vez de curl/Swagger), com upload de
imagem, e gerencia clientes: ver saldo e extrato de cada um, e lançar
ajustes manuais de pontos (bônus, correção, estorno) — sempre com um
motivo, que fica registrado no extrato do cliente.

**Primeiro acesso — crie o admin inicial:**

O painel não tem tela de "criar conta" (de propósito — ver
`Controllers/AdminAuthController.cs`). O primeiro administrador é criado
uma única vez, pelo Swagger ou curl, e essa rota se fecha sozinha depois
(passa a responder 403) assim que existir 1 admin:

```bash
curl -k -X POST https://localhost:7xxx/api/admin/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Seu Nome","email":"admin@gsdishopping.com.br","password":"umaSenhaForte123"}'
```

Depois disso, entre pelo navegador em `/admin/login` com esse e-mail/senha.

**Como funciona por baixo:** o app cliente e o Swagger continuam
autenticando com JWT (Bearer), como sempre. O painel Blazor usa cookie de
sessão (login em `/admin/login`, 8h de validade) — os dois esquemas
convivem no mesmo backend (ver `Program.cs`, esquema "Smart" +
policy `"AdminOnly"`), sem CORS nem servidor separado, porque o painel
consulta o banco direto (mesmo `DbContext`), sem passar pela própria API.

**Ledger, não contador:** um ajuste manual de pontos não mexe num "saldo"
em lugar nenhum — ele só adiciona uma linha em `PointsAdjustments`, e o
saldo do cliente continua sendo sempre a soma (compras aprovadas + ajustes),
calculada na hora (ver `PointsService.GetBalanceAsync`). Isso é o mesmo
princípio de `PointTransactions` desde a Fase 1 (seção "Por que o saldo de
pontos não é uma coluna", no fim deste arquivo) — só que agora a soma tem
duas fontes em vez de uma. O extrato do cliente na Fase 3 passou a misturar
os dois tipos de linha (compra e ajuste), tanto no app quanto no painel.

## 6. Contrato com o seu serviço externo de validação

Este backend chama `POST {ExternalValidation:BaseUrl}/validate` com
`{ accessKey, storeCnpj, totalValue }` e espera de volta
`{ approved: bool, reason?: string }`. Se o seu serviço externo usar um
formato diferente, o único arquivo que precisa mudar é
`Services/ExternalReceiptValidationService.cs` — o resto da API depende
só da interface `IExternalReceiptValidationService`.

## Estrutura

```
GSDIShoppingApi/
  Program.cs              # wiring: EF Core/MySQL, JWT + cookie admin, CORS, DI, Blazor
  Models/                 # ApplicationUser, PointTransaction, ReceiptStatus, Store, Campaign, Coupon,
                           # Promotion, AdminUser, PointsAdjustment
  Data/GSDIShoppingDbContext.cs
  Dtos/                   # contratos de request/response
  Services/
    JwtTokenService.cs
    ExternalReceiptValidationService.cs   # cliente HTTP do seu serviço externo
    PointsService.cs                      # orquestra duplicidade + elegibilidade + validação + pontos
    DocumentValidators.cs                 # validação de e-mail, telefone, CPF, CNPJ
    ImageUploadService.cs                 # salva imagens enviadas pelo painel em wwwroot/uploads/
  Controllers/
    AuthController.cs        # /api/auth/register, /api/auth/login (cliente final)
    WalletController.cs      # /api/wallet/balance, /api/wallet/transactions
    ReceiptsController.cs    # /api/receipts/validate
    CatalogController.cs     # /api/catalog/{stores,campaigns,coupons,promotions} — leitura pública, escrita exige admin
    AdminAuthController.cs   # /api/admin/auth/register (bootstrap), /api/admin/auth/login
    AdminUsersController.cs  # /api/admin/users — listar clientes, ver extrato, ajustar pontos
  Components/              # painel de administração (Blazor Server) — ver seção 5.7
    Pages/Admin/            # Login, Lojas, Campanhas, Cupons, Promoções, Usuários, extrato do usuário
    Layout/
  wwwroot/                 # css do painel + uploads/ (imagens enviadas)
  schema.sql
  migration_fase1.sql      # Stores + PointTransactions.StoreId (rodar só se o banco já existia antes da Fase 1)
  migration_fase2.sql      # Campaigns + Coupons + Promotions (rodar só se o banco já existia antes da Fase 2)
  migration_fase3.sql      # AdminUsers + PointsAdjustments (rodar só se o banco já existia antes da Fase 3)
```

## Por que o saldo de pontos não é uma coluna

`PointTransactions` é um livro-razão (append-only): o saldo é sempre a
soma dos pontos das transações aprovadas (`PointsService.GetBalanceAsync`),
nunca um contador guardado à parte. Isso evita bugs de concorrência (duas
notas processadas ao mesmo tempo dessincronizando um contador) e já dá o
extrato de graça. O índice único em `AccessKey` é a garantia, no nível do
banco, de que a mesma nota nunca gera pontos duas vezes.

Desde a Fase 3, `PointsAdjustments` (ajustes manuais feitos por um admin)
segue o mesmo princípio: também é append-only, e entra na mesma soma que
forma o saldo — nunca um contador separado que alguém poderia
dessincronizar. Ver seção 5.7.
