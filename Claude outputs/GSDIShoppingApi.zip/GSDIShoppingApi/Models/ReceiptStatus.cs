namespace GSDIShoppingApi.Models;

public enum ReceiptStatus
{
    Approved = 0,
    RejectedDuplicate = 1,
    RejectedInvalid = 2,
}
