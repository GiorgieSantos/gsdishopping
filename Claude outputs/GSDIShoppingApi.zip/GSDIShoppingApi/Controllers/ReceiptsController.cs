using GSDIShoppingApi.Dtos.Receipts;
using GSDIShoppingApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GSDIShoppingApi.Controllers;

[ApiController]
[Route("api/receipts")]
[Authorize]
public class ReceiptsController(IPointsService pointsService) : ControllerBase
{
    /// <summary>
    /// Recebe a chave de acesso lida do QR code da nota, o CNPJ da loja e o
    /// valor, e devolve se foi aprovada e quantos pontos o usuário ganhou.
    /// A loja em si é resolvida aqui dentro a partir do CNPJ — ver
    /// PointsService para o fluxo completo de validação, incluindo a
    /// checagem de elegibilidade.
    /// </summary>
    [HttpPost("validate")]
    public async Task<ActionResult<ValidateReceiptResponse>> Validate(
        ValidateReceiptRequest request, CancellationToken ct)
    {
        var result = await pointsService.ProcessReceiptAsync(User.GetUserId(), request, ct);
        return Ok(result);
    }
}
