using System.Security.Claims;
using System.Text;
using GSDIShoppingApi.Data;
using GSDIShoppingApi.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

// --- Banco de dados (MySQL via Pomelo) ---
// Duas formas de registro de propósito: AddDbContext dá um DbContext
// "scoped por requisição" pros controllers de API; AddDbContextFactory dá
// uma fábrica pros componentes Blazor do painel — um componente Blazor
// Server vive pela duração inteira da conexão (circuit), então guardar um
// DbContext injetado direto nele (em vez de criar um novo por operação)
// é um erro clássico de concorrência/tempo de vida. Os componentes do
// painel usam a fábrica; os controllers usam o DbContext normal.
var connectionString = builder.Configuration.GetConnectionString("Default")
    ?? throw new InvalidOperationException("ConnectionStrings:Default não configurada.");
void ConfigureDb(DbContextOptionsBuilder options) =>
    options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString));
builder.Services.AddDbContext<GSDIShoppingDbContext>(ConfigureDb);
builder.Services.AddDbContextFactory<GSDIShoppingDbContext>(ConfigureDb);

// --- Autenticação: JWT (API) + cookie (painel Blazor), lado a lado ---
// O app cliente e o Swagger/automação continuam usando Bearer JWT, sem
// mudanças. O painel de administração (/admin/**) é acessado num
// navegador comum, então usa cookie de sessão — é o próprio
// HttpContext.SignInAsync("AdminCookie", ...) feito no POST /admin/login
// mais abaixo. O esquema "Smart" decide qual dos dois usar por caminho da
// requisição: /admin/** (páginas do painel) vai de cookie, todo o resto
// (a API, incluindo /api/admin/**) continua indo de JWT como sempre foi.
var jwtKey = builder.Configuration["Jwt:Key"]
    ?? throw new InvalidOperationException("Jwt:Key não configurada.");
const string AdminCookieScheme = "AdminCookie";
builder.Services
    .AddAuthentication(options =>
    {
        options.DefaultScheme = "Smart";
        options.DefaultAuthenticateScheme = "Smart";
        options.DefaultChallengeScheme = "Smart";
    })
    .AddPolicyScheme("Smart", "JWT (API) ou cookie (painel), por caminho", options =>
    {
        options.ForwardDefaultSelector = context =>
            context.Request.Path.StartsWithSegments("/admin")
                ? AdminCookieScheme
                : JwtBearerDefaults.AuthenticationScheme;
    })
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
        };
    })
    .AddCookie(AdminCookieScheme, options =>
    {
        options.LoginPath = "/admin/login";
        options.AccessDeniedPath = "/admin/login";
        options.Cookie.Name = "GSDIShoppingAdmin";
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
        options.SlidingExpiration = true;
    });

builder.Services.AddAuthorizationBuilder()
    .AddPolicy("AdminOnly", policy => policy
        .AddAuthenticationSchemes(JwtBearerDefaults.AuthenticationScheme, AdminCookieScheme)
        .RequireRole("Admin"));

// --- Serviços de aplicação ---
builder.Services.AddScoped<IJwtTokenService, JwtTokenService>();
builder.Services.AddScoped<IPointsService, PointsService>();
builder.Services.AddScoped<ImageUploadService>();

builder.Services.AddHttpClient<IExternalReceiptValidationService, ExternalReceiptValidationService>(client =>
{
    var baseUrl = builder.Configuration["ExternalValidation:BaseUrl"];
    if (!string.IsNullOrWhiteSpace(baseUrl))
    {
        client.BaseAddress = new Uri(baseUrl.TrimEnd('/') + "/");
    }
    client.Timeout = TimeSpan.FromSeconds(10);
});

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// --- Painel de administração (Blazor Server, dentro deste mesmo projeto) ---
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// Libera o app Flutter (em dev) a chamar esta API de qualquer origem.
// Em produção, troque WithOrigins("*") pelos domínios reais do seu app.
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy => policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseStaticFiles(); // serve wwwroot/ — inclui as imagens enviadas pelo painel em wwwroot/uploads/
app.UseCors();
app.UseAuthentication();
app.UseAuthorization();
app.UseAntiforgery();
app.MapControllers();

// --- Login/logout do painel: fora dos componentes Blazor de propósito ---
// Um componente Blazor Server interativo roda sobre uma conexão
// já aberta (SignalR) — nesse ponto a resposta HTTP inicial já foi
// enviada, então não dá mais para escrever um cookie nela
// (HttpContext.SignInAsync precisa rodar ANTES da resposta ser
// finalizada). Por isso login/logout são endpoints comuns, e a página
// Components/Pages/Admin/Login.razor é renderizada estática (sem
// @rendermode), postando pra cá como um formulário HTML normal.
app.MapPost("/admin/login", async (HttpContext http, GSDIShoppingDbContext db) =>
{
    var form = await http.Request.ReadFormAsync();
    var email = form["email"].ToString().Trim();
    var password = form["password"].ToString();
    var returnUrl = form["returnUrl"].ToString();

    var admin = await db.AdminUsers.SingleOrDefaultAsync(a => a.Email == email);
    if (admin is null || !BCrypt.Net.BCrypt.Verify(password, admin.PasswordHash))
    {
        var failTarget = "/admin/login?erro=1"
            + (string.IsNullOrEmpty(returnUrl) ? "" : $"&returnUrl={Uri.EscapeDataString(returnUrl)}");
        return Results.Redirect(failTarget);
    }

    var claims = new List<Claim>
    {
        new(ClaimTypes.NameIdentifier, admin.Id.ToString()),
        new(ClaimTypes.Name, admin.Name),
        new(ClaimTypes.Email, admin.Email),
        new(ClaimTypes.Role, "Admin"),
    };
    var identity = new ClaimsIdentity(claims, AdminCookieScheme);
    await http.SignInAsync(AdminCookieScheme, new ClaimsPrincipal(identity));

    var safeReturn = !string.IsNullOrEmpty(returnUrl) && returnUrl.StartsWith('/') && returnUrl.StartsWith("/admin")
        ? returnUrl
        : "/admin/lojas";
    return Results.Redirect(safeReturn);
});

app.MapPost("/admin/logout", async (HttpContext http) =>
{
    await http.SignOutAsync(AdminCookieScheme);
    return Results.Redirect("/admin/login");
});

app.MapRazorComponents<GSDIShoppingApi.Components.App>()
    .AddInteractiveServerRenderMode();

app.Run();
